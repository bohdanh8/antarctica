module.exports = {
    // This is the name of the zip file that will be created when the "build" script is executed (starter-wp-theme.zip).
    themeName: 'starter-wp-theme',
};
