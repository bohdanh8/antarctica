<?php

/**
 * debug.log file path when using the function, debug_log(). Please specify the local path of the Github repo you are using.
 */
const DEBUG_LOG_PATH = '/Users/kaveengoonawardane/Documents/Github/starter-wp-theme';
