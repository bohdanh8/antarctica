<?php

/**
 * Fonts that needs to be pre-loaded should go here.
 */
?>
<link rel="preload" href="<?php echo get_template_directory_uri() ?>/assets/fonts/mark-pro-350-subset.woff2" as="font" type="font/woff2" crossorigin="">

<link rel="preload" href="<?php echo get_template_directory_uri() ?>/assets/fonts/mark-pro-500-subset.woff2" as="font" type="font/woff2" crossorigin="">