// Services accordion
const accordion = require(MODULES_PATH + '/accordion');

new accordion({
    selector: '.accordion',
    duration: 200,
    openOnInit: [],
});
