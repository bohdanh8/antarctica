<?php get_component( "news-section" ); ?>
