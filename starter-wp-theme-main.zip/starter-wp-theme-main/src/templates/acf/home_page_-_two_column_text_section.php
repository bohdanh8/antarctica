<?php get_component( "two_column_text" ); ?>
