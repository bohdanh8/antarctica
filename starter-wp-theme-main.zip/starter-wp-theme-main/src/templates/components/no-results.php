<?php

/**
 * @var array{size: string} $args
 */
?>
<div class="col-span-full">
	<h4><?php echo __("No search results.", 'prosekwptheme'); ?></h4>
	<p><?php echo __("Try to adjust your search keywords or filter options to find what you're looking for.", 'prosekwptheme'); ?></p>
</div>