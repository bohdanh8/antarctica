<span class="absolute -inset-2"></span>
<span class="position-center block h-5 w-7 sm:h-6 sm:w-9 [&>span]:transition-all [&>span]:duration-300 text-prosek-dark-gray">
   <span class="absolute rounded-full top-0 block bg-current h-1 w-full group-[.active]/nav-button:rotate-45 group-[.active]/nav-button:top-1/2 group-[.active]/nav-button:-mt-0.5"></span>
   <span class="absolute rounded-full top-1/2 block bg-current h-1 w-full -mt-0.5 group-[.active]/nav-button:opacity-0"></span>
   <span class="absolute rounded-full top-full block bg-current h-1 w-full -mt-1 group-[.active]/nav-button:-rotate-45 group-[.active]/nav-button:top-1/2 group-[.active]/nav-button:-mt-0.5"></span>
</span>